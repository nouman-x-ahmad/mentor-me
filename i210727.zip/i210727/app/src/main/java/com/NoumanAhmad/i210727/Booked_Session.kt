package com.NoumanAhmad.i210727

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Booked_Session : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booked_session)
    }
}