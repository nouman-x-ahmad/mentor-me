package com.NoumanAhmad.i210727

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Camera : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
    }
}