package com.NoumanAhmad.i210727

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class review_page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_page)
    }
}